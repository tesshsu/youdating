import * as LOVE from './LOVE';
import * as PRO from './PRO';
import * as SOCIAL from './SOCIAL';
import * as PERSO from './PERSO';

export {
  LOVE,
  PRO,
  SOCIAL,
  PERSO
};
